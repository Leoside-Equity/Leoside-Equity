/* ==========================================================================
   Leoside Equity: home page
   ========================================================================== */
Boot.start('index', function () {
  'use strict';

  const user = Auth.current();
  const latest = REPORTS[0];
  const esc = LS.esc;

  /* ------------------------------------------------------- market sessions
     Regular hours only, read in each exchange's own time zone through the
     browser's Intl support, so daylight saving is handled for us. Holidays
     and early closes are not known here, and the page says so. */
  function localParts(tz) {
    const parts = {};
    new Intl.DateTimeFormat('en-GB', { timeZone: tz, weekday: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' })
      .formatToParts(new Date()).forEach(function (p) { parts[p.type] = p.value; });
    const hh = (+parts.hour) % 24, mm = +parts.minute;
    return { wd: parts.weekday, mins: hh * 60 + mm, text: String(hh).padStart(2, '0') + ':' + String(mm).padStart(2, '0') };
  }
  function toMins(hhmm) { const p = hhmm.split(':'); return (+p[0]) * 60 + (+p[1]); }
  function session(ex) {
    const t = localParts(ex.tz);
    const weekend = t.wd === 'Sat' || t.wd === 'Sun';
    const from = toMins(ex.open), to = toMins(ex.close);
    const open = !weekend && t.mins >= from && t.mins < to;
    let state = open ? 'Open' : 'Closed';
    if (!open && !weekend && t.mins < from) state = 'Opens ' + ex.open;
    /* How far through today's session: 0 before the open, 1 after the close. */
    const done = weekend ? 0 : Math.max(0, Math.min(1, (t.mins - from) / (to - from)));
    return { time: t.text, open: open, state: state, done: done };
  }

  /* A strip that scrolls sideways on its own. It moves only when there is
     enough to fill it, stops for a pointer or keyboard focus, and carries a
     pause button (WCAG 2.2.2). The copies that make the loop seamless are
     hidden from screen readers and from the tab order. */
  function marquee(root, items, pxPerSecond, label) {
    const track = root.querySelector('.reel__track');
    const view = track.parentElement;
    const setClass = 'reel__set';
    track.innerHTML = '';
    const first = document.createElement('div');
    first.className = setClass;
    first.innerHTML = items.join('');
    track.appendChild(first);
    /* A short list is repeated inside the first run until it is wider than
       the screen, so the strip always fills and always moves. The repeats
       are for the eye only. */
    const once = first.getBoundingClientRect().width;
    if (once > 0 && once < view.clientWidth * 1.1) {
      const extra = Math.ceil((view.clientWidth * 1.1) / once) - 1;
      for (let k = 0; k < extra; k++) {
        const wrap = document.createElement('div');
        wrap.innerHTML = items.join('');
        Array.prototype.slice.call(wrap.children).forEach(function (el) {
          el.setAttribute('aria-hidden', 'true');
          if (el.tagName === 'A') el.setAttribute('tabindex', '-1');
          first.appendChild(el);
        });
      }
    }
    const lap = first.getBoundingClientRect().width;
    if (lap < view.clientWidth * 0.9) return;
    const copies = Math.max(2, Math.ceil((view.clientWidth * 2) / lap) + 1);
    for (let n = 1; n < copies; n++) {
      const c = first.cloneNode(true);
      c.setAttribute('aria-hidden', 'true');
      c.querySelectorAll('a').forEach(function (a) { a.setAttribute('tabindex', '-1'); });
      track.appendChild(c);
    }
    track.style.setProperty('--lap', lap + 'px');
    track.style.setProperty('--lap-time', Math.max(20, Math.round(lap / pxPerSecond)) + 's');
    if (LS.reducedMotion()) return;
    root.classList.add('is-moving');
    const btn = root.querySelector('.reel__ctl');
    if (!btn) return;
    const paint = function () {
      const paused = root.classList.contains('is-paused');
      btn.innerHTML = LS.icon(paused ? 'play' : 'pause') + '<span>' + (paused ? 'Play' : 'Pause') + '</span>';
      btn.setAttribute('aria-label', (paused ? 'Resume ' : 'Pause ') + label);
      btn.setAttribute('aria-pressed', String(paused));
    };
    btn.hidden = false;
    btn.addEventListener('click', function () { root.classList.toggle('is-paused'); paint(); });
    paint();
  }

  /* "NIKE Inc. (Class B common stock)" reads as "NIKE Inc." in display type. */
  function shortName(name) {
    return String(name || '').replace(/\s*\([^)]*\)\s*/g, ' ').replace(/\s+/g, ' ').trim();
  }

  /* --------------------------------------------------------------- hero */
  const cta = document.getElementById('heroCta');
  if (cta) {
    cta.innerHTML =
      (latest ? '<a class="btn btn--lg" href="' + LS.reportUrl(latest.id) + '">Read the latest report</a>'
              : '<a class="btn btn--lg" href="reports.html">Read the reports</a>') +
      (user ? '<a class="btn btn--ghost btn--lg" href="dashboard.html">Your dashboard</a>'
            : '<a class="btn btn--ghost btn--lg" href="signup.html">Create a free account</a>');
  }

  const todayIso = LS.toISO(new Date());
  const todayMarket = LS.market(LS.marketForToday());
  /* -------------------------------------------------------------- clocks
     Pressing an exchange turns the globe to it. */
  let globe = null;
  const clocks = document.getElementById('clocks');
  function paintClocks() {
    if (!clocks) return;
    const buttons = clocks.querySelectorAll('.clock');
    REGION_ORDER.forEach(function (code, i) {
      const btn = buttons[i];
      if (!btn) return;
      const s = session(REGIONS[code].exchange);
      btn.querySelector('.clock__time').textContent = s.time;
      const state = btn.querySelector('.clock__state');
      state.textContent = s.state;
      state.classList.toggle('is-open', s.open);
    });
  }
  if (clocks) {
    const buttons = clocks.querySelectorAll('.clock');
    REGION_ORDER.forEach(function (code, i) {
      const btn = buttons[i];
      if (!btn) return;
      btn.classList.toggle('is-focus', code === todayMarket.code);
      btn.addEventListener('click', function () {
        buttons.forEach(function (b) { b.classList.toggle('is-focus', b === btn); });
        if (globe) globe.turnTo(REGIONS[code].exchange.lon);
      });
    });
    paintClocks();
    setInterval(paintClocks, 30000);
  }

  const stage = document.getElementById('globeStage');
  if (stage && typeof Globe !== 'undefined') {
    globe = Globe.mount(stage, {
      focusLon: (REGIONS[todayMarket.code] || REGIONS.US).exchange.lon,
      focusLat: 24,
      markers: REGION_ORDER.map(function (code) {
        const ex = REGIONS[code].exchange;
        return {
          label: ex.short, lat: ex.lat, lon: ex.lon,
          isOpen: function () { return session(ex).open; },
          time: function () { return session(ex).time; }
        };
      })
    });
    const fb = document.getElementById('globeFallback');
    if (fb) fb.remove();
  }

  /* --------------------------------------------------------- lead story */
  function cover(r) {
    const m = LS.market(r.market);
    return '<a class="cover" href="' + LS.reportUrl(r.id) + '" tabindex="-1" aria-hidden="true">' +
      '<span class="book">' +
        '<span class="book__back"></span><span class="book__top"></span><span class="book__edge"></span>' +
        '<span class="book__face book__face--' + m.slug + '">' +
          '<span class="book__mast"><img src="/assets/img/logo-64.webp" alt="" width="32" height="32" decoding="async">Leoside Equity</span>' +
          '<span class="book__kind">' + esc(m.name) + '</span>' +
          '<span class="book__tk">' + esc(r.ticker) + '</span>' +
          '<span class="book__co">' + esc(shortName(r.company)) + '</span>' +
          '<span class="book__foot"><span>' + esc(r.exchange || m.venues) + '</span><span>' + LS.fmtDate(r.date, 'medium') + '</span></span>' +
        '</span>' +
      '</span></a>';
  }

  const lead = document.getElementById('lead');
  if (lead) {
    if (!latest) {
      lead.innerHTML =
        '<div class="empty empty--flat"><h3>The first report is being written</h3>' +
        '<p>Nothing has been published yet. When it is, the newest report appears here and in the archive, newest first.</p>' +
        '<a class="btn btn--ghost" href="reports.html">Open the archive</a></div>';
    } else {
      const priced = LS.hasValuation(latest.market);
      lead.innerHTML =
        '<div class="feature">' +
          '<article>' +
            '<div class="feature__meta">' + LS.marketTag(latest.market) +
              '<time datetime="' + esc(latest.date) + '">' + LS.fmtDate(latest.date) + '</time>' +
              (priced ? LS.ratingTag(latest.rating) : '') + '</div>' +
            '<h3><a href="' + LS.reportUrl(latest.id) + '">' + esc(latest.title) + '</a></h3>' +
            '<p class="feature__stand">' + esc(latest.standfirst) + '</p>' +
            '<ul class="feature__facts">' +
              '<li><b>' + esc(shortName(latest.company)) + '</b></li>' +
              '<li>' + esc((latest.exchange ? latest.exchange + ': ' : '') + latest.ticker) + '</li>' +
              '<li>' + (latest.readMins || 1) + ' minute read</li>' +
            '</ul>' +
            '<div class="feature__actions">' +
              '<a class="btn btn--lg" href="' + LS.reportUrl(latest.id) + '">Read the report ' + LS.icon('arrow') + '</a>' +
            '</div>' +
          '</article>' +
          cover(latest) +
        '</div>';
    }
  }
  /* ---------------------------------------------------------------- reel
     Every company covered, newest first, in display type. Until there are
     a few, it names the three exchange cities instead. */
  const reel = document.getElementById('reel');
  if (reel) {
    const seen = {};
    const companies = REPORTS.filter(function (r) {
      const key = String(r.ticker).toUpperCase();
      if (seen[key]) return false;
      seen[key] = true;
      return true;
    }).slice(0, 16);
    let items;
    if (companies.length >= 3) {
      items = companies.map(function (r) {
        return '<a class="reel__item reel__item--' + LS.market(r.market).slug + '" href="' + LS.reportUrl(r.id) + '">' +
          esc(shortName(r.company)) + '<span class="reel__tk">' + esc(r.ticker) + '</span></a>';
      });
    } else {
      reel.setAttribute('aria-label', 'The three exchanges covered');
      items = REGION_ORDER.map(function (code) {
        const r = REGIONS[code];
        return '<span class="reel__item reel__item--' + r.slug + '">' + esc(r.exchange.city) + '<span class="reel__tk">' + esc(r.exchange.short) + '</span></span>';
      });
    }
    marquee(reel, items, 42, 'the list of companies covered');
  }

  /* -------------------------------------------------------------- recent */
  const recent = document.getElementById('recent');
  if (recent) {
    const more = REPORTS.slice(1, 5);
    if (!more.length) recent.remove();
    else recent.innerHTML = more.map(Cards.index).join('');
  }
  /* ---------------------------------------------------------------- week
     This week's seven days in a row, grouped under their markets, with the
     ticker on any day that already has a report. Built from SITE.schedule,
     so it can never disagree with it. */
  const bar = document.getElementById('weekbar');
  if (bar) {
    const now = new Date();
    const monday = new Date(now.getFullYear(), now.getMonth(), now.getDate() - ((now.getDay() + 6) % 7));
    const byDate = {};
    REPORTS.forEach(function (r) { if (!byDate[r.date]) byDate[r.date] = r; });
    const segs = [];
    for (let i = 0; i < 7; i++) {
      const d = new Date(monday.getFullYear(), monday.getMonth(), monday.getDate() + i);
      const code = LS.market(SITE.schedule[d.getDay()]).code;
      const last = segs[segs.length - 1];
      if (last && last.code === code) last.days.push(d);
      else segs.push({ code: code, days: [d] });
    }
    bar.innerHTML = segs.map(function (s) {
      const r = REGIONS[s.code];
      const short = r.code === 'IN' ? r.name : r.code;
      return '<li class="weekbar__seg weekbar__seg--' + r.slug + '" style="--span:' + s.days.length + '">' +
        '<h3 class="weekbar__name"><a href="reports.html?region=' + s.code + '"><span class="long">' + esc(r.name) + '</span><span class="short">' + esc(short) + '</span></a></h3>' +
        '<div class="weekbar__days">' + s.days.map(function (d) {
          const iso = LS.toISO(d);
          const today = iso === todayIso;
          const rep = byDate[iso];
          const inner = '<span class="wday__name" aria-hidden="true">' + LS.DAYS_S[d.getDay()] + '</span>' +
            '<span class="wday__date" aria-hidden="true">' + d.getDate() + '</span>' +
            (rep ? '<span class="wday__tk" aria-hidden="true">' + esc(rep.ticker) + '</span>' : '');
          const label = LS.fmtDate(iso) + (today ? ', today' : '') + (rep ? ': ' + rep.title : '');
          return rep
            ? '<a class="wday' + (today ? ' is-today' : '') + '" href="' + LS.reportUrl(rep.id) + '" aria-label="' + esc(label) + '"' + (today ? ' aria-current="date"' : '') + '>' + inner + '</a>'
            : '<span class="wday' + (today ? ' is-today' : '') + '"' + (today ? ' aria-current="date"' : '') + '><span class="sr-only">' + esc(label) + '</span>' + inner + '</span>';
        }).join('') + '</div>' +
      '</li>';
    }).join('');
  }

  /* ------------------------------------------------------------ bottom */
  const band = document.getElementById('joinBand');
  if (band && user) band.remove();

  if (new URLSearchParams(location.search).get('deleted') === '1') {
    LS.toast('Your account and everything attached to it has been deleted.');
  }
});
